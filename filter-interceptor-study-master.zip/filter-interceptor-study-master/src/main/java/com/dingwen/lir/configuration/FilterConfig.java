package com.dingwen.lir.configuration;

import com.dingwen.lir.filter.RequestFilter;
import com.dingwen.lir.filter.RequestWrapper;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;

/**
 * 过滤器配置类
 *
 * @author dingwen
 * 2021.04.30 16:10
 */
@Configuration
public class FilterConfig {

    @Bean
    public RequestFilter requestFilter(){
        return new RequestFilter();
    }
    @Bean
    public FilterRegistrationBean<RequestFilter> registrationBean() {
        FilterRegistrationBean<RequestFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(requestFilter());
        registrationBean.addUrlPatterns("/filter/*");
        registrationBean.setName("RequestFilter");
        //过滤器的级别，值越小级别越高越先执行
        registrationBean.setOrder(1);
        return registrationBean;
    }
}
