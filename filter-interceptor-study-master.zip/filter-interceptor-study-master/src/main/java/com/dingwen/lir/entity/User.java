package com.dingwen.lir.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * 用户实体
 *
 * @author dingwen
 * 2021.04.26 17:59
 */
@Getter
@Setter
@ToString
public class User implements Serializable {
    private static final long serialVersionUID = -7273790659980485787L;
    private String account;
    private String password;
}
