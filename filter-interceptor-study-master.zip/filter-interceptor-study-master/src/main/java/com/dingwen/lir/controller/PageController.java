package com.dingwen.lir.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 页面跳转控制器
 *
 * @author dingwen
 * 2021.04.26 17:45
 */
@Controller
@RequestMapping("/page")
public class PageController {
    /*
     * 首页跳转
     * @return String
     */
    @GetMapping("/index")
    public String index() {
        return "index";
    }

    /*
     *  登录页跳转
     * @return String
     */
    @GetMapping("/login")
    public String login(){
        return "login";
    }


    /*
     *  用户页跳转
     * @return String
     */
    @GetMapping("/user")
    public String user(){
        return "user";
    }


    /*
     * ajax请求跳转
     * @return String
     */
//    @GetMapping("/ajax")
//    public String ajax(){
//        return "ajax";
//    }
}
