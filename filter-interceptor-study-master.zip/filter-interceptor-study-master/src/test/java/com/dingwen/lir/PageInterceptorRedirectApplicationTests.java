package com.dingwen.lir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PageInterceptorRedirectApplicationTests {

    @Test
    void contextLoads() {
    }

}
